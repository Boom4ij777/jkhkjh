import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export interface Product {
  id: string;
  title: string;
  description: string;
  price: number;
  category: 'Android' | 'iOS' | 'Root' | 'PC';
  image?: string;
}

export interface Order {
  id: string;
  productId: string;
  customerName: string;
  paymentProof: string; // Base64 or mock URL
  status: 'pending' | 'approved' | 'rejected';
  date: number;
  chatId?: string;
}

export interface ChatMessage {
  id: string;
  sender: 'admin' | 'user';
  text: string;
  timestamp: number;
}

export interface ChatSession {
  id: string; // usually orderId
  messages: ChatMessage[];
}

interface AppState {
  siteName: string;
  paymentMethods: string;
  products: Product[];
  orders: Order[];
  chats: Record<string, ChatMessage[]>;
  isAdmin: boolean;
  currentUser: string | null; // Username of currently logged in user

  // Actions
  setSiteName: (name: string) => void;
  setPaymentMethods: (methods: string) => void;
  toggleAdmin: (status: boolean) => void;
  login: (username: string) => void;
  logout: () => void;
  addProduct: (product: Product) => void;
  updateProduct: (id: string, updates: Partial<Product>) => void;
  deleteProduct: (id: string) => void;
  createOrder: (order: Order) => void;
  updateOrderStatus: (id: string, status: Order['status']) => void;
  sendMessage: (chatId: string, message: ChatMessage) => void;
}

// Initial Mock Data
const initialProducts: Product[] = [
  {
    id: '1',
    title: 'PUBG Mobile ESP - Android (No Root)',
    description: 'Безопасный ESP с Именами, Здоровьем, Дистанцией и Скелетом. Работает на всех версиях Android.',
    price: 15,
    category: 'Android'
  },
  {
    id: '2',
    title: 'Aimbot Pro - iOS',
    description: 'Silent Aim, Magic Bullet, Меньше отдачи. Требуется Jailbreak.',
    price: 25,
    category: 'iOS'
  },
  {
    id: '3',
    title: 'Emulator King - PC',
    description: 'Обход детекта эмулятора. Все функции включены.',
    price: 20,
    category: 'PC'
  },
  {
    id: '4',
    title: 'Root God Mode',
    description: 'Только для Root прав. Летающие машины, спидхак, инстант хит.',
    price: 35,
    category: 'Root'
  }
];

export const useStore = create<AppState>()(
  persist(
    (set) => ({
      siteName: 'BraisStore',
      paymentMethods: 'USDT (TRC20): T...Example\nCard: 0000 0000 0000 0000\nPayPal: brais@store.com',
      products: initialProducts,
      orders: [],
      chats: {},
      isAdmin: false,
      currentUser: null,

      setSiteName: (name) => set({ siteName: name }),
      setPaymentMethods: (methods) => set({ paymentMethods: methods }),
      toggleAdmin: (status) => set({ isAdmin: status }),
      login: (username) => set({ currentUser: username, isAdmin: username === 'BraisGufik' }),
      logout: () => set({ currentUser: null, isAdmin: false }),
      
      addProduct: (product) => set((state) => ({ 
        products: [...state.products, product] 
      })),
      
      updateProduct: (id, updates) => set((state) => ({
        products: state.products.map(p => p.id === id ? { ...p, ...updates } : p)
      })),
      
      deleteProduct: (id) => set((state) => ({
        products: state.products.filter(p => p.id !== id)
      })),
      
      createOrder: (order) => set((state) => ({
        orders: [order, ...state.orders],
        chats: { ...state.chats, [order.id]: [] } // Initialize chat for order
      })),
      
      updateOrderStatus: (id, status) => set((state) => ({
        orders: state.orders.map(o => o.id === id ? { ...o, status } : o)
      })),
      
      sendMessage: (chatId, message) => set((state) => ({
        chats: {
          ...state.chats,
          [chatId]: [...(state.chats[chatId] || []), message]
        }
      })),
    }),
    {
      name: 'brais-store-storage',
    }
  )
);
