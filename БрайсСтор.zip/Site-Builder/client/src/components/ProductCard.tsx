import { motion } from "framer-motion";
import { Product } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ShoppingCart, ShieldCheck, Zap } from "lucide-react";

interface ProductCardProps {
  product: Product;
  onBuy: (product: Product) => void;
}

export function ProductCard({ product, onBuy }: ProductCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -5 }}
      transition={{ duration: 0.3 }}
    >
      <Card className="h-full flex flex-col bg-card/50 border-white/10 backdrop-blur-sm hover:border-primary/50 transition-colors group overflow-hidden relative">
        {/* Holiday Decoration */}
        <div className="absolute -top-10 -right-10 w-20 h-20 bg-primary/20 blur-2xl rounded-full group-hover:bg-primary/40 transition-all" />
        
        <CardHeader>
          <div className="flex justify-between items-start">
            <Badge variant="outline" className="bg-secondary/20 text-secondary border-secondary/50 font-gaming">
              {product.category}
            </Badge>
            <div className="text-xl font-bold font-gaming text-accent">${product.price}</div>
          </div>
          <CardTitle className="font-gaming text-xl mt-2 group-hover:text-primary transition-colors">
            {product.title}
          </CardTitle>
          <CardDescription className="line-clamp-2">
            {product.description}
          </CardDescription>
        </CardHeader>
        
        <CardContent className="flex-grow space-y-2">
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <ShieldCheck className="h-4 w-4 text-secondary" />
            <span>Невидимый</span>
          </div>
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <Zap className="h-4 w-4 text-accent" />
            <span>Мгновенная доставка</span>
          </div>
        </CardContent>
        
        <CardFooter>
          <Button 
            className="w-full font-gaming bg-primary hover:bg-primary/90 text-white shadow-[0_0_15px_rgba(220,38,38,0.5)] hover:shadow-[0_0_25px_rgba(220,38,38,0.7)] transition-all"
            onClick={() => onBuy(product)}
          >
            <ShoppingCart className="mr-2 h-4 w-4" />
            Купить
          </Button>
        </CardFooter>
      </Card>
    </motion.div>
  );
}
