import { useState } from "react";
import { useStore, Order, ChatMessage, Product } from "@/lib/store";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Trash2, Edit, CheckCircle, XCircle, Send, Shield, MessageSquare } from "lucide-react";

export function AdminPanel() {
  const store = useStore();
  const [activeOrder, setActiveOrder] = useState<string | null>(null);
  const [chatInput, setChatInput] = useState("");

  // Product Form State
  const [isEditing, setIsEditing] = useState<string | null>(null);
  const [productForm, setProductForm] = useState<{
    title: string;
    price: number;
    category: Product['category'];
    description: string;
  }>({
    title: "",
    price: 0,
    category: "Android",
    description: ""
  });

  const handleSaveProduct = () => {
    if (isEditing) {
      store.updateProduct(isEditing, productForm);
      setIsEditing(null);
    } else {
      store.addProduct({
        id: Math.random().toString(36).substring(7),
        ...productForm
      });
    }
    setProductForm({ title: "", price: 0, category: "Android", description: "" });
  };

  const handleSendChat = (orderId: string) => {
    if (!chatInput.trim()) return;
    store.sendMessage(orderId, {
      id: Math.random().toString(),
      sender: 'admin',
      text: chatInput,
      timestamp: Date.now()
    });
    setChatInput("");
  };

  const selectedOrder = store.orders.find(o => o.id === activeOrder);
  const orderChat = activeOrder ? store.chats[activeOrder] || [] : [];

  return (
    <div className="p-6 space-y-8">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-holiday text-primary flex items-center gap-2">
          <Shield className="w-8 h-8" />
          Админ Панель
        </h1>
        <div className="space-x-2">
          <Input 
            className="w-64 inline-block bg-black/20" 
            value={store.siteName}
            onChange={(e) => store.setSiteName(e.target.value)}
            placeholder="Название сайта"
          />
        </div>
      </div>

      <Tabs defaultValue="orders" className="w-full">
        <TabsList className="w-full bg-black/20 border border-white/10">
          <TabsTrigger value="orders">Заказы и Чат</TabsTrigger>
          <TabsTrigger value="products">Товары</TabsTrigger>
          <TabsTrigger value="settings">Настройки оплаты</TabsTrigger>
        </TabsList>

        {/* ORDERS TAB */}
        <TabsContent value="orders" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Order List */}
            <div className="md:col-span-1 space-y-4">
              <h3 className="text-lg font-gaming text-accent">Последние заказы</h3>
              <ScrollArea className="h-[600px] rounded-lg border border-white/10 bg-black/20 p-4">
                {store.orders.length === 0 ? (
                  <p className="text-muted-foreground text-center py-8">Заказов пока нет.</p>
                ) : (
                  store.orders.map(order => (
                    <div 
                      key={order.id}
                      className={`p-4 rounded-lg mb-3 cursor-pointer border transition-all ${
                        activeOrder === order.id 
                          ? 'bg-primary/10 border-primary' 
                          : 'bg-card/50 border-white/5 hover:bg-white/5'
                      }`}
                      onClick={() => setActiveOrder(order.id)}
                    >
                      <div className="flex justify-between mb-2">
                        <span className="font-bold text-sm">#{order.id}</span>
                        <Badge variant={
                          order.status === 'approved' ? 'default' : 
                          order.status === 'rejected' ? 'destructive' : 'secondary'
                        }>{order.status}</Badge>
                      </div>
                      <p className="text-sm text-muted-foreground">{order.customerName}</p>
                      <p className="text-xs text-white/50 mt-1">
                        {new Date(order.date).toLocaleDateString()}
                      </p>
                    </div>
                  ))
                )}
              </ScrollArea>
            </div>

            {/* Order Details & Chat */}
            <div className="md:col-span-2">
              {selectedOrder ? (
                <div className="grid grid-cols-1 gap-6">
                  {/* Proof Viewer */}
                  <Card className="bg-black/20 border-white/10">
                    <CardHeader>
                      <CardTitle className="flex justify-between items-center">
                        <span>Детали заказа #{selectedOrder.id}</span>
                        <div className="flex gap-2">
                          <Button size="sm" variant="destructive" onClick={() => store.updateOrderStatus(selectedOrder.id, 'rejected')}>
                            <XCircle className="w-4 h-4 mr-1" /> Отклонить
                          </Button>
                          <Button size="sm" className="bg-secondary hover:bg-secondary/80" onClick={() => store.updateOrderStatus(selectedOrder.id, 'approved')}>
                            <CheckCircle className="w-4 h-4 mr-1" /> Принять
                          </Button>
                        </div>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-2 gap-4 mb-4 text-sm">
                         <div>
                            <p className="text-muted-foreground">Покупатель:</p>
                            <p className="font-bold text-accent">{selectedOrder.customerName}</p>
                         </div>
                         <div>
                            <p className="text-muted-foreground">Сумма:</p>
                            <p className="font-bold">${store.products.find(p => p.id === selectedOrder.productId)?.price || '???'}</p>
                         </div>
                      </div>
                      <div className="aspect-video bg-black rounded-lg overflow-hidden mb-4 flex items-center justify-center border border-white/10 relative group">
                        <img 
                          src={selectedOrder.paymentProof} 
                          alt="Payment Proof" 
                          className="max-h-full max-w-full object-contain"
                        />
                        <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                           <a href={selectedOrder.paymentProof} target="_blank" rel="noopener noreferrer" className="text-white underline font-bold">
                              Открыть оригинал
                           </a>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Chat */}
                  <Card className="bg-black/20 border-white/10 flex flex-col h-[500px]">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-lg">Чат с покупателем: {selectedOrder.customerName}</CardTitle>
                    </CardHeader>
                    <CardContent className="flex-grow flex flex-col overflow-hidden">
                      <ScrollArea className="flex-grow p-4 bg-black/20 rounded-lg mb-4 border border-white/5">
                        <div className="space-y-4">
                          {orderChat.length === 0 && <p className="text-center text-muted-foreground text-sm">Истории сообщений нет.</p>}
                          {orderChat.map(msg => (
                            <div key={msg.id} className={`flex flex-col ${msg.sender === 'admin' ? 'items-end' : 'items-start'}`}>
                              <span className="text-[10px] text-muted-foreground mb-1 px-1">
                                {msg.sender === 'admin' ? 'Вы (Администратор)' : selectedOrder.customerName}
                              </span>
                              <div className={`max-w-[80%] p-3 rounded-lg text-sm ${
                                msg.sender === 'admin' 
                                  ? 'bg-secondary text-white rounded-tr-none' 
                                  : 'bg-primary/80 text-white rounded-tl-none'
                              }`}>
                                <p>{msg.text}</p>
                              </div>
                              <span className="text-[10px] opacity-50 mt-1 px-1 block">
                                {new Date(msg.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                              </span>
                            </div>
                          ))}
                        </div>
                      </ScrollArea>
                      <div className="flex gap-2">
                        <Input 
                          value={chatInput}
                          onChange={(e) => setChatInput(e.target.value)}
                          placeholder="Написать покупателю..."
                          onKeyDown={(e) => e.key === 'Enter' && handleSendChat(selectedOrder.id)}
                          className="bg-black/20"
                        />
                        <Button onClick={() => handleSendChat(selectedOrder.id)}>
                          <Send className="w-4 h-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              ) : (
                <div className="h-full flex flex-col items-center justify-center text-muted-foreground border border-dashed border-white/10 rounded-lg bg-black/10 min-h-[400px]">
                  <MessageSquare className="w-12 h-12 mb-4 opacity-20" />
                  <p>Выберите заказ слева, чтобы открыть чат</p>
                </div>
              )}
            </div>
          </div>
        </TabsContent>

        {/* PRODUCTS TAB */}
        <TabsContent value="products" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Form */}
            <Card className="md:col-span-1 h-fit bg-black/20 border-white/10">
              <CardHeader>
                <CardTitle>{isEditing ? 'Редактировать товар' : 'Добавить товар'}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-xs text-muted-foreground">Название</label>
                  <Input 
                    value={productForm.title}
                    onChange={(e) => setProductForm({...productForm, title: e.target.value})}
                  />
                </div>
                <div>
                  <label className="text-xs text-muted-foreground">Цена</label>
                  <Input 
                    type="number"
                    value={productForm.price}
                    onChange={(e) => setProductForm({...productForm, price: Number(e.target.value)})}
                  />
                </div>
                <div>
                  <label className="text-xs text-muted-foreground">Категория</label>
                  <select 
                    className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 bg-black/20"
                    value={productForm.category}
                    onChange={(e) => setProductForm({...productForm, category: e.target.value as any})}
                  >
                    <option value="Android">Android</option>
                    <option value="iOS">iOS</option>
                    <option value="Root">Root</option>
                    <option value="PC">PC</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs text-muted-foreground">Описание</label>
                  <Textarea 
                    value={productForm.description}
                    onChange={(e) => setProductForm({...productForm, description: e.target.value})}
                  />
                </div>
                <div className="flex gap-2">
                  <Button className="w-full" onClick={handleSaveProduct}>
                    {isEditing ? 'Обновить' : 'Добавить'}
                  </Button>
                  {isEditing && (
                    <Button variant="outline" onClick={() => {
                      setIsEditing(null);
                      setProductForm({ title: "", price: 0, category: "Android", description: "" });
                    }}>Отмена</Button>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* List */}
            <div className="md:col-span-2 grid grid-cols-1 gap-4">
              {store.products.map(product => (
                <Card key={product.id} className="bg-card/50 border-white/5">
                  <CardContent className="p-4 flex justify-between items-center">
                    <div>
                      <div className="font-bold font-gaming">{product.title}</div>
                      <div className="text-sm text-muted-foreground">{product.category} - ${product.price}</div>
                    </div>
                    <div className="flex gap-2">
                      <Button size="icon" variant="ghost" onClick={() => {
                        setIsEditing(product.id);
                        setProductForm({
                          title: product.title,
                          price: product.price,
                          category: product.category,
                          description: product.description
                        });
                      }}>
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button size="icon" variant="ghost" className="text-destructive" onClick={() => store.deleteProduct(product.id)}>
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </TabsContent>

        {/* SETTINGS TAB */}
        <TabsContent value="settings">
          <Card className="bg-black/20 border-white/10">
            <CardHeader>
              <CardTitle>Настройка методов оплаты</CardTitle>
            </CardHeader>
            <CardContent>
              <Textarea 
                className="min-h-[200px] font-mono bg-black/20"
                value={store.paymentMethods}
                onChange={(e) => store.setPaymentMethods(e.target.value)}
              />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
