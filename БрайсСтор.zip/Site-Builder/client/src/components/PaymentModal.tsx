import { useState, useCallback } from "react";
import { useDropzone } from "react-dropzone";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Product, useStore } from "@/lib/store";
import { Upload, Check, Copy, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface PaymentModalProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
}

export function PaymentModal({ product, isOpen, onClose }: PaymentModalProps) {
  const [name, setName] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();
  
  const paymentMethods = useStore((state) => state.paymentMethods);
  const createOrder = useStore((state) => state.createOrder);

  const onDrop = useCallback((acceptedFiles: File[]) => {
    if (acceptedFiles?.[0]) {
      setFile(acceptedFiles[0]);
    }
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({ 
    onDrop,
    accept: { 'image/*': [] },
    maxFiles: 1
  });

  const handleSubmit = async () => {
    if (!product || !name || !file) {
      toast({
        title: "Недостаточно данных",
        description: "Пожалуйста, укажите имя и прикрепите скриншот.",
        variant: "destructive"
      });
      return;
    }

    setIsSubmitting(true);

    // Simulate upload delay
    setTimeout(() => {
      // Convert file to object URL for mock display
      const fileUrl = URL.createObjectURL(file);
      
      createOrder({
        id: Math.random().toString(36).substring(7),
        productId: product.id,
        customerName: name,
        paymentProof: fileUrl,
        status: 'pending',
        date: Date.now()
      });

      toast({
        title: "Заказ отправлен!",
        description: "Администратор скоро проверит оплату. Проверьте профиль.",
      });

      setIsSubmitting(false);
      setName("");
      setFile(null);
      onClose();
    }, 1500);
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({ title: "Скопировано" });
  };

  if (!product) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-card/95 backdrop-blur-xl border-white/10 max-w-md">
        <DialogHeader>
          <DialogTitle className="font-holiday text-2xl text-primary">Оформление: {product.title}</DialogTitle>
          <DialogDescription>
            Цена: <span className="text-accent font-bold">${product.price}</span>
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* Payment Info */}
          <div className="space-y-2 p-4 bg-black/20 rounded-lg border border-white/5">
            <Label className="text-xs uppercase text-muted-foreground">Инструкции по оплате</Label>
            <div className="text-sm font-mono whitespace-pre-wrap text-foreground/90">
              {paymentMethods}
            </div>
            <Button 
              variant="outline" 
              size="sm" 
              className="w-full mt-2 text-xs"
              onClick={() => copyToClipboard(paymentMethods)}
            >
              <Copy className="h-3 w-3 mr-2" /> Копировать
            </Button>
          </div>

          {/* User Info */}
          <div className="space-y-2">
            <Label>Ваше имя (для проверки)</Label>
            <Input 
              value={name} 
              onChange={(e) => setName(e.target.value)} 
              placeholder="Введите имя или ник"
              className="bg-background/50"
            />
          </div>

          {/* Upload */}
          <div className="space-y-2">
            <Label>Скриншот оплаты</Label>
            <div 
              {...getRootProps()} 
              className={`
                border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-colors
                ${isDragActive ? 'border-primary bg-primary/10' : 'border-white/10 hover:border-primary/50'}
                ${file ? 'border-secondary bg-secondary/10' : ''}
              `}
            >
              <input {...getInputProps()} />
              {file ? (
                <div className="flex flex-col items-center gap-2 text-secondary">
                  <Check className="h-8 w-8" />
                  <p className="text-sm font-medium">{file.name}</p>
                </div>
              ) : (
                <div className="flex flex-col items-center gap-2 text-muted-foreground">
                  <Upload className="h-8 w-8" />
                  <p className="text-sm">Нажмите или перетащите скриншот сюда</p>
                </div>
              )}
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button variant="ghost" onClick={onClose}>Отмена</Button>
          <Button 
            onClick={handleSubmit} 
            disabled={isSubmitting || !file || !name}
            className="bg-primary hover:bg-primary/90 text-white"
          >
            {isSubmitting ? <Loader2 className="h-4 w-4 animate-spin" /> : "Подтвердить оплату"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
