import { useState } from "react";
import { useStore } from "@/lib/store";
import { AdminPanel } from "@/components/AdminPanel";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { MessageSquare, Send, User, LogOut } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function Profile() {
  const store = useStore();
  const [loginInput, setLoginInput] = useState("");
  const [chatInput, setChatInput] = useState("");

  const handleUserSendChat = (orderId: string) => {
    if (!chatInput.trim()) return;
    store.sendMessage(orderId, {
      id: Math.random().toString(),
      sender: 'user',
      text: chatInput,
      timestamp: Date.now()
    });
    setChatInput("");
  };

  const handleLogin = () => {
    if (loginInput.trim()) {
      store.login(loginInput);
    }
  };

  if (store.isAdmin) {
    return (
      <div className="min-h-screen pt-20 pb-10 container mx-auto">
         <div className="flex justify-end px-6 mb-4">
            <Button variant="ghost" onClick={() => {
              store.logout();
              setLoginInput("");
            }}>
              <LogOut className="w-4 h-4 mr-2" />
              Выйти из Админки
            </Button>
         </div>
        <AdminPanel />
      </div>
    );
  }

  if (!store.currentUser) {
    return (
      <div className="min-h-screen pt-24 pb-10 px-4 container mx-auto max-w-md flex items-center justify-center">
        <Card className="w-full bg-card/50 border-white/10 backdrop-blur-md">
          <CardHeader>
            <CardTitle className="font-holiday text-3xl text-primary text-center">
              Вход в Профиль
            </CardTitle>
            <CardDescription className="text-center">
              Войдите, чтобы отслеживать свои заказы
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Input 
              placeholder="Ваше имя пользователя" 
              value={loginInput}
              onChange={(e) => setLoginInput(e.target.value)}
              className="bg-black/20 text-center"
            />
            <Button className="w-full bg-primary hover:bg-primary/90" onClick={handleLogin}>
              Войти
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const userOrders = store.orders.filter(o => o.customerName === store.currentUser);

  // User View
  return (
    <div className="min-h-screen pt-24 pb-10 px-4 container mx-auto max-w-4xl">
      <div className="space-y-8">
        <div className="flex justify-between items-center">
          <h1 className="text-3xl font-holiday text-primary flex items-center gap-2">
            <User className="h-8 w-8" />
            Привет, {store.currentUser}!
          </h1>
          <Button variant="ghost" onClick={() => store.logout()}>
            <LogOut className="w-4 h-4 mr-2" />
            Выйти
          </Button>
        </div>

        <div className="space-y-4">
          <h2 className="text-2xl font-gaming text-accent">Мои Заказы</h2>
          
          {userOrders.length === 0 ? (
            <div className="text-center py-12 border border-dashed border-white/10 rounded-lg bg-black/5">
              <p className="text-muted-foreground">У вас пока нет заказов.</p>
            </div>
          ) : (
            <div className="grid gap-4">
              {userOrders.map(order => {
                const product = store.products.find(p => p.id === order.productId);
                const orderChat = store.chats[order.id] || [];
                
                return (
                  <Card key={order.id} className="bg-black/20 border-white/5 overflow-hidden">
                    <CardHeader className="bg-white/5 pb-3">
                      <div className="flex justify-between items-center">
                        <div className="flex flex-col">
                          <span className="font-bold text-lg">{product?.title || 'Неизвестный товар'}</span>
                          <span className="text-xs text-muted-foreground">ID Заказа: #{order.id}</span>
                        </div>
                        <Badge variant={
                          order.status === 'approved' ? 'default' : 
                          order.status === 'rejected' ? 'destructive' : 'secondary'
                        } className="capitalize">
                          {order.status === 'approved' ? 'Принят' : order.status === 'rejected' ? 'Отклонен' : 'Ожидание'}
                        </Badge>
                      </div>
                    </CardHeader>
                    
                    <CardContent className="pt-4">
                      <div className="grid md:grid-cols-2 gap-6">
                        <div className="space-y-2 text-sm">
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Цена:</span>
                            <span className="font-mono text-accent">${product?.price}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Дата:</span>
                            <span>{new Date(order.date).toLocaleDateString()}</span>
                          </div>
                          <div className="mt-4 p-3 bg-black/30 rounded border border-white/5">
                            <p className="text-xs text-muted-foreground mb-1">Ваш скриншот:</p>
                            <img src={order.paymentProof} alt="proof" className="h-20 object-contain mx-auto" />
                          </div>
                        </div>

                        {/* Mini Chat for User */}
                        <div className="border border-white/10 rounded-lg flex flex-col h-[300px] bg-black/40">
                          <div className="p-2 border-b border-white/5 bg-white/5 text-xs font-bold flex items-center gap-2">
                            <MessageSquare className="w-3 h-3" /> Чат поддержки
                          </div>
                          <ScrollArea className="flex-grow p-2">
                            <div className="space-y-3 pr-3">
                              {orderChat.length === 0 && (
                                <p className="text-xs text-center text-muted-foreground mt-4">
                                  Напишите админу, если есть вопросы.
                                </p>
                              )}
                              {orderChat.map(msg => (
                                <div key={msg.id} className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}>
                                  <span className="text-[10px] text-muted-foreground mb-1 px-1">
                                    {msg.sender === 'user' ? 'Вы' : 'Администратор'}
                                  </span>
                                  <div className={`max-w-[85%] p-2 rounded-lg text-xs ${
                                    msg.sender === 'user' 
                                      ? 'bg-primary text-white rounded-tr-none' 
                                      : 'bg-secondary/80 text-white rounded-tl-none'
                                  }`}>
                                    {msg.text}
                                  </div>
                                  <span className="text-[9px] opacity-50 mt-1 px-1">
                                    {new Date(msg.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                                  </span>
                                </div>
                              ))}
                            </div>
                          </ScrollArea>
                          <div className="p-2 border-t border-white/5 flex gap-2">
                            <Input 
                              className="h-8 text-xs" 
                              placeholder="Сообщение..."
                              value={chatInput}
                              onChange={(e) => setChatInput(e.target.value)}
                              onKeyDown={(e) => e.key === 'Enter' && handleUserSendChat(order.id)}
                            />
                            <Button size="icon" className="h-8 w-8" onClick={() => handleUserSendChat(order.id)}>
                              <Send className="w-3 h-3" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
