import { useState } from "react";
import { useStore, Product } from "@/lib/store";
import { ProductCard } from "@/components/ProductCard";
import { PaymentModal } from "@/components/PaymentModal";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { motion } from "framer-motion";

export default function Home() {
  const products = useStore((state) => state.products);
  const [activeCategory, setActiveCategory] = useState<string>("Все");
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const categories = ["Все", "Android", "iOS", "Root", "PC"];

  const filteredProducts = activeCategory === "Все" 
    ? products 
    : products.filter(p => p.category === activeCategory);

  const handleBuy = (product: Product) => {
    setSelectedProduct(product);
    setIsModalOpen(true);
  };

  return (
    <div className="min-h-screen pt-20 pb-10 px-4">
      {/* Hero Section */}
      <section className="text-center py-20 space-y-6 relative">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-primary/10 blur-[100px] rounded-full -z-10" />
        
        <motion.h1 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-5xl md:text-7xl font-bold font-holiday text-white drop-shadow-[0_0_15px_rgba(255,255,255,0.3)]"
        >
          Новогодняя Распродажа <span className="text-primary">Live!</span>
        </motion.h1>
        <motion.p 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="text-lg text-muted-foreground max-w-2xl mx-auto"
        >
          Премиум читы для PUBG Mobile. Безопасно, надежно, мгновенно.
          Получи преимущество, которое тебе нужно в этот праздничный сезон.
        </motion.p>
      </section>

      {/* Filter Tabs */}
      <div className="flex justify-center mb-12">
        <Tabs defaultValue="Все" className="w-full max-w-md" onValueChange={setActiveCategory}>
          <TabsList className="grid w-full grid-cols-5 bg-black/40 border border-white/10 backdrop-blur-md">
            {categories.map(cat => (
              <TabsTrigger 
                key={cat} 
                value={cat}
                className="font-gaming text-xs md:text-sm data-[state=active]:bg-primary data-[state=active]:text-white"
              >
                {cat}
              </TabsTrigger>
            ))}
          </TabsList>
        </Tabs>
      </div>

      {/* Product Grid */}
      <div className="container mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {filteredProducts.length > 0 ? (
          filteredProducts.map(product => (
            <ProductCard key={product.id} product={product} onBuy={handleBuy} />
          ))
        ) : (
          <div className="col-span-full text-center py-20 text-muted-foreground">
            В этой категории пока нет товаров.
          </div>
        )}
      </div>

      <PaymentModal 
        product={selectedProduct} 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)} 
      />
    </div>
  );
}
